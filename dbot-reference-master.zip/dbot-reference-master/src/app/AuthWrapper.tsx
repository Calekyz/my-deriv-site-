import React from 'react';
import App from './App';

export const AuthWrapper = () => {
    return <App />;
};
