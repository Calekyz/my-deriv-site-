import Download from './download';
import './download.scss';

export default Download;
