import ButtonLink from './button-link';

export default ButtonLink;
