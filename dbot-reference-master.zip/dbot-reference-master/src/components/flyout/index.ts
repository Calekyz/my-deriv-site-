import Flyout from './flyout';
import './flyout.scss';

export default Flyout;
