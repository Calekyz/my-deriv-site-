import DataList from './data-list';
import './data-list.scss';

export default DataList;
