import ErrorModal from './error-modal';
import './error-modal.scss';

export default ErrorModal;
