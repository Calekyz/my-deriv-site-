import LocalStorageSyncWrapper from './localStorage-sync-wrapper';

export default LocalStorageSyncWrapper;
