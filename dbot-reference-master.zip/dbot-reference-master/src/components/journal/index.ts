import Journal from './journal';
import './journal.scss';

export default Journal;
