import CustomNotifications from './custom-notifications';

export default CustomNotifications;
