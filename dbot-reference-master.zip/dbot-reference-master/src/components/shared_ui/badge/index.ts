import Badge from './badge';
import './badge.scss';

export default Badge;
