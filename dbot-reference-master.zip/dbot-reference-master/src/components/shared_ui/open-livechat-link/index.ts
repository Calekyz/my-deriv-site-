import OpenLiveChatLink from './open-livechat-link';

export default OpenLiveChatLink;
