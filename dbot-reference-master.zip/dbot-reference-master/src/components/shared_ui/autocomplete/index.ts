import Autocomplete from './autocomplete';
import './autocomplete.scss';

export default Autocomplete;
