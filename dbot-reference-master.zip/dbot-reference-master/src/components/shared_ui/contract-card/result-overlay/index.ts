import ResultOverlay from './result-overlay';
import './result-overlay.scss';

export default ResultOverlay;
