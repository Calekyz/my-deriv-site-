import Button from './button';
import './button.scss';

export default Button;
