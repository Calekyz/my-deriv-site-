import ToggleSwitch from './toggle-switch';
import './toggle-switch.scss';

export default ToggleSwitch;
