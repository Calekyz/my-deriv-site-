import AppLinkedWithWalletIcon from './app-linked-with-wallet-icon';

export { AppLinkedWithWalletIcon };
