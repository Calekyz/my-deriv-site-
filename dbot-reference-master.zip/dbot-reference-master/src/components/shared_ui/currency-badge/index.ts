import CurrencyBadge from './currency-badge';
import './currency-badge.scss';

export default CurrencyBadge;
