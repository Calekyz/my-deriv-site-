import InputField from './input-field';
import './input-field.scss';

export default InputField;
