import RemainingTime from './remaining-time';

export default RemainingTime;
