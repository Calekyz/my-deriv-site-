import DesktopWrapper from './desktop-wrapper';
import './desktop-wrapper.scss';

export default DesktopWrapper;
