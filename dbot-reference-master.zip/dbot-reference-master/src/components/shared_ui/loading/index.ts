import Loading from './loading';
import './loading.scss';

export default Loading;
