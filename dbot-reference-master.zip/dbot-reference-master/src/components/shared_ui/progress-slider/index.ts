import ProgressSlider from './progress-slider';
import './progress-slider.scss';

export default ProgressSlider;
