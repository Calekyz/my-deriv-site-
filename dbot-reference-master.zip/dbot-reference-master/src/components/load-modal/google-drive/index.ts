import GoogleDrive from './google-drive';

export default GoogleDrive;
