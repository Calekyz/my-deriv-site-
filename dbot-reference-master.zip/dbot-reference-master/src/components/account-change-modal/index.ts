import AccountChangeModal from './account-change-modal';

export default AccountChangeModal;
