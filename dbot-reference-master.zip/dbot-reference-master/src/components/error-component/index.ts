import ErrorComponent from './error-component';

export default ErrorComponent;
