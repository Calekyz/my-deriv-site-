import ContractResultOverlay from './contract-result-overlay';
import './contract-result-overlay.scss';

export default ContractResultOverlay;
