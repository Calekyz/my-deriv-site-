import PageError from './page-error';
import './page-error.scss';

export default PageError;
